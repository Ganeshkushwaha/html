﻿using System;

namespace oops
{
    class firstdemo
    {
        public int a;
    }
    struct seconddemo
    {
        public int a;
    }
    public class Encapsulation
    {
        private int pr = 10;
        protected int pro;
        public int p;

        static void main(string[] args)
        {
            Encapsulation e1 = new Encapsulation();
            Console.ReadLine();
            Console.WriteLine(e1.pr);
            
        }


    }
    class thirddemo : Encapsulation
    {
        static void main(string[] args)
        {
            thirddemo e1 = new thirddemo();
            e1.pro = 10;
            Console.WriteLine(",kjhsd"+e1.pro);
        }

    }
    class polymorphism
    {
        public void demo()
        {
            Console.WriteLine("no argument");
        }
        public void demo(int b)
        {
            Console.WriteLine("one argument");
        }
        public void demo(int b,string c)
        {
            Console.WriteLine("method overloading");
        }
        
    }   
    class base_class
    {
        public void demo()
        {
            Console.WriteLine("base class function");
        }
    }
    class sub_class: base_class
    {
        public void demo()
        {
            Console.WriteLine("sub_class function");
        }
    }
    
    abstract class a_class
    {
        public void normal()
        {
            Console.WriteLine("normal function can be written in abstract class");
        }
        public abstract void normal1();
    }
    abstract class b_class : a_class
    {
        public abstract void normalb1();
        public void normalb2()
        {
            Console.WriteLine("mathod of this class is called");
        }
        public override void normal1()
        {
            Console.WriteLine("method of abstract calss of a _class defination");
        }

    }
    class c_class : b_class
    {
        public override void normalb1()
        {
            Console.WriteLine("B_class abstract method defination");
        }

        public override void normal1()
        {
            Console.WriteLine("A_class abstract defination");
        }
    }   
    interface d_class
    {
        void I1();
    }
    interface e_class
    {
        void I1();
    }
    class f_class : d_class, e_class
    {
        void d_class.I1()
        {
            Console.WriteLine("first interface is reffered");
        }
        void e_class.I1()
        {
            Console.WriteLine("second interface is reffered");
        }
    }
    static class static_class
    {
        public static int a;
    }
    class static_deno
    {
        public int a;

        public static int b;
    }
    class demo_1
    {
        public int c;
    }
    sealed class demo_2: demo_1
    {

        public int d;
    }




    class program
    {
        public static void Main(string[] args)
        {
            firstdemo f12 = new firstdemo();
            firstdemo f2 = new firstdemo();
            firstdemo f3 = new firstdemo();
            firstdemo f4 = new firstdemo();
            firstdemo f5 = f2;
            firstdemo f6 = f3; 
            firstdemo f7 = f4;
            f12.a = 10;
            f2.a = 20;
            f3.a = 30;
            f4.a = 50;
            f5.a = 70;
            f6.a = 80;
            f7.a = 100;

            /*Console.WriteLine("value of a is " + f12.a);
            Console.WriteLine("value of a is " + f2.a);
            Console.WriteLine("value of a is " + f3.a);
            Console.WriteLine("value of a is " + f4.a);
            Console.WriteLine("value of a is " + f5.a);
            Console.WriteLine("value of a is " + f6.a);
            Console.WriteLine("value of a is " + f7.a);*/



            seconddemo f8 = new seconddemo();
            seconddemo f9 = new seconddemo();
            seconddemo f10 = new seconddemo();
            seconddemo f11 = f8;
            seconddemo f13 = f9;
            f10.a = 20;
            f11.a = 30;
            //Console.WriteLine("valuse of a is "+f10.a);
            //Console.WriteLine("value of a is "+f11.a);
            thirddemo f14 = new thirddemo();
            f14.p = 50;
            //Console.WriteLine("value f14  "+f14.p);
            
            polymorphism po = new polymorphism();
            //po.demo();
            //po.demo(2);
            //po.demo(3, "oijwrk");

            base_class b1 = new base_class();
            //b1.demo();

            sub_class s1 = new sub_class();
            //s1.demo();

            a_class a1 = new c_class();
            //a1.normal();
            //a1.normal1();
            
            c_class c1 = new c_class();
            //c1.normalb1();

            d_class d1 = new f_class();
            //d1.I1();
            e_class e1 = new f_class();
            //e1.I1();

            static_class.a = 20;
            //Console.WriteLine(static_class.a);

            static_deno.b = 30;
            //Console.WriteLine(static_deno.b);
        }
        
        
        
    }

}

    